$(document).ready(function(){
    $("#sidenav").load("SideNav.html");
    
});